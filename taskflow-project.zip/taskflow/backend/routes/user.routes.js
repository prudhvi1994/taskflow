const express = require('express');
const router = express.Router();
const { getUsers, getUserStats } = require('../controllers/user.controller');
const { protect, authorize } = require('../middleware/auth.middleware');

router.use(protect);
router.get('/stats', getUserStats);
router.get('/', authorize('admin'), getUsers);

module.exports = router;
