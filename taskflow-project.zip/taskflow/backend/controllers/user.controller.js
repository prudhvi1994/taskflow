const User = require('../models/User.model');
const Task = require('../models/Task.model');
const { createError } = require('../utils/error.utils');

// @desc    Get all users (admin only)
// @route   GET /api/users
exports.getUsers = async (req, res, next) => {
  try {
    const users = await User.find({}).select('-password');
    res.json({ success: true, count: users.length, users });
  } catch (error) {
    next(error);
  }
};

// @desc    Get user stats
// @route   GET /api/users/stats
exports.getUserStats = async (req, res, next) => {
  try {
    const [taskStats, user] = await Promise.all([
      Task.aggregate([
        { $match: { user: req.user._id } },
        {
          $group: {
            _id: null,
            total: { $sum: 1 },
            completed: { $sum: { $cond: [{ $eq: ['$status', 'completed'] }, 1, 0] } },
            pending: { $sum: { $cond: [{ $eq: ['$status', 'pending'] }, 1, 0] } },
            highPriority: { $sum: { $cond: [{ $eq: ['$priority', 'high'] }, 1, 0] } },
          },
        },
      ]),
      User.findById(req.user._id),
    ]);

    const stats = taskStats[0] || { total: 0, completed: 0, pending: 0, highPriority: 0 };
    res.json({ success: true, stats, user });
  } catch (error) {
    next(error);
  }
};
