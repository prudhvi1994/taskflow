const Task = require('../models/Task.model');
const { createError } = require('../utils/error.utils');

// @desc    Get all tasks (with filters, search, pagination)
// @route   GET /api/tasks
exports.getTasks = async (req, res, next) => {
  try {
    const { status, priority, search, page = 1, limit = 10, sortBy = 'createdAt', order = 'desc' } = req.query;

    const query = { user: req.user._id };

    if (status && status !== 'all') query.status = status;
    if (priority) query.priority = priority;
    if (search) {
      query.$or = [
        { title: { $regex: search, $options: 'i' } },
        { description: { $regex: search, $options: 'i' } },
      ];
    }

    const pageNum = parseInt(page, 10);
    const limitNum = parseInt(limit, 10);
    const skip = (pageNum - 1) * limitNum;
    const sortOrder = order === 'asc' ? 1 : -1;

    const [tasks, total] = await Promise.all([
      Task.find(query).sort({ [sortBy]: sortOrder }).skip(skip).limit(limitNum),
      Task.countDocuments(query),
    ]);

    const stats = await Task.aggregate([
      { $match: { user: req.user._id } },
      { $group: { _id: '$status', count: { $sum: 1 } } },
    ]);

    const statsMap = { pending: 0, completed: 0 };
    stats.forEach((s) => (statsMap[s._id] = s.count));

    res.json({
      success: true,
      tasks,
      pagination: {
        total,
        page: pageNum,
        limit: limitNum,
        totalPages: Math.ceil(total / limitNum),
        hasMore: pageNum < Math.ceil(total / limitNum),
      },
      stats: { ...statsMap, all: statsMap.pending + statsMap.completed },
    });
  } catch (error) {
    next(error);
  }
};

// @desc    Get single task
// @route   GET /api/tasks/:id
exports.getTask = async (req, res, next) => {
  try {
    const task = await Task.findOne({ _id: req.params.id, user: req.user._id });
    if (!task) return next(createError('Task not found', 404));
    res.json({ success: true, task });
  } catch (error) {
    next(error);
  }
};

// @desc    Create task
// @route   POST /api/tasks
exports.createTask = async (req, res, next) => {
  try {
    const { title, description, priority, dueDate, tags } = req.body;
    const task = await Task.create({
      title, description, priority, dueDate, tags,
      user: req.user._id,
    });
    res.status(201).json({ success: true, message: 'Task created', task });
  } catch (error) {
    next(error);
  }
};

// @desc    Update task
// @route   PUT /api/tasks/:id
exports.updateTask = async (req, res, next) => {
  try {
    const task = await Task.findOneAndUpdate(
      { _id: req.params.id, user: req.user._id },
      req.body,
      { new: true, runValidators: true }
    );
    if (!task) return next(createError('Task not found', 404));
    res.json({ success: true, message: 'Task updated', task });
  } catch (error) {
    next(error);
  }
};

// @desc    Delete task
// @route   DELETE /api/tasks/:id
exports.deleteTask = async (req, res, next) => {
  try {
    const task = await Task.findOneAndDelete({ _id: req.params.id, user: req.user._id });
    if (!task) return next(createError('Task not found', 404));
    res.json({ success: true, message: 'Task deleted' });
  } catch (error) {
    next(error);
  }
};

// @desc    Toggle task status
// @route   PATCH /api/tasks/:id/toggle
exports.toggleTask = async (req, res, next) => {
  try {
    const task = await Task.findOne({ _id: req.params.id, user: req.user._id });
    if (!task) return next(createError('Task not found', 404));

    task.status = task.status === 'pending' ? 'completed' : 'pending';
    await task.save();

    res.json({ success: true, message: `Task marked as ${task.status}`, task });
  } catch (error) {
    next(error);
  }
};

// @desc    Bulk delete tasks
// @route   DELETE /api/tasks/bulk
exports.bulkDelete = async (req, res, next) => {
  try {
    const { ids } = req.body;
    if (!ids || !ids.length) return next(createError('No task IDs provided', 400));

    const result = await Task.deleteMany({ _id: { $in: ids }, user: req.user._id });
    res.json({ success: true, message: `${result.deletedCount} tasks deleted` });
  } catch (error) {
    next(error);
  }
};
