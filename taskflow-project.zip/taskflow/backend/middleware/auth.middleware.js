const jwt = require('jsonwebtoken');
const User = require('../models/User.model');
const { createError } = require('../utils/error.utils');

// Protect routes - verify JWT
exports.protect = async (req, res, next) => {
  try {
    let token;

    if (req.headers.authorization?.startsWith('Bearer')) {
      token = req.headers.authorization.split(' ')[1];
    }

    if (!token) {
      return next(createError('Not authorized to access this route', 401));
    }

    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    const user = await User.findById(decoded.id);

    if (!user || !user.isActive) {
      return next(createError('User not found or deactivated', 401));
    }

    req.user = user;
    next();
  } catch (error) {
    return next(createError('Not authorized, token failed', 401));
  }
};

// Role-based authorization
exports.authorize = (...roles) => {
  return (req, res, next) => {
    if (!roles.includes(req.user.role)) {
      return next(createError(`Role '${req.user.role}' is not authorized for this action`, 403));
    }
    next();
  };
};
