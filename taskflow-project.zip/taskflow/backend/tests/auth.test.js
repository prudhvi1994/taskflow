const request = require('supertest');
const app = require('../app');

describe('Auth Endpoints', () => {
  const testUser = {
    name: 'Test User',
    email: `test${Date.now()}@example.com`,
    password: 'password123',
  };

  describe('POST /api/auth/register', () => {
    it('should register a new user', async () => {
      const res = await request(app).post('/api/auth/register').send(testUser);
      expect(res.statusCode).toBe(201);
      expect(res.body.success).toBe(true);
      expect(res.body.token).toBeDefined();
    });

    it('should fail with missing fields', async () => {
      const res = await request(app).post('/api/auth/register').send({ email: 'bad@test.com' });
      expect(res.statusCode).toBe(400);
    });
  });

  describe('POST /api/auth/login', () => {
    it('should fail with wrong credentials', async () => {
      const res = await request(app).post('/api/auth/login').send({
        email: 'wrong@test.com', password: 'wrongpass',
      });
      expect(res.statusCode).toBe(401);
    });
  });
});
