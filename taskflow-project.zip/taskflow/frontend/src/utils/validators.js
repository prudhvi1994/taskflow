export const validateLogin = (values) => {
  const errors = {};
  if (!values.email) errors.email = 'Email is required';
  else if (!/\S+@\S+\.\S+/.test(values.email)) errors.email = 'Invalid email address';
  if (!values.password) errors.password = 'Password is required';
  return errors;
};

export const validateRegister = (values) => {
  const errors = {};
  if (!values.name) errors.name = 'Name is required';
  else if (values.name.length < 2) errors.name = 'Name must be at least 2 characters';
  if (!values.email) errors.email = 'Email is required';
  else if (!/\S+@\S+\.\S+/.test(values.email)) errors.email = 'Invalid email address';
  if (!values.password) errors.password = 'Password is required';
  else if (values.password.length < 6) errors.password = 'Password must be at least 6 characters';
  if (!values.confirmPassword) errors.confirmPassword = 'Please confirm your password';
  else if (values.password !== values.confirmPassword) errors.confirmPassword = 'Passwords do not match';
  return errors;
};

export const validateTask = (values) => {
  const errors = {};
  if (!values.title || !values.title.trim()) errors.title = 'Title is required';
  else if (values.title.length > 100) errors.title = 'Title cannot exceed 100 characters';
  if (values.description && values.description.length > 500) errors.description = 'Description max 500 characters';
  return errors;
};
