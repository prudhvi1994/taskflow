import { format, isValid, parseISO, isPast } from 'date-fns';

export const formatDate = (date, fmt = 'MMM dd, yyyy') => {
  if (!date) return 'No due date';
  const d = typeof date === 'string' ? parseISO(date) : date;
  return isValid(d) ? format(d, fmt) : 'Invalid date';
};

export const isOverdue = (date, status) => {
  if (!date || status === 'completed') return false;
  const d = typeof date === 'string' ? parseISO(date) : date;
  return isValid(d) && isPast(d);
};

export const getPriorityColor = (priority) => {
  const map = {
    high: { color: 'var(--priority-high)', bg: 'var(--priority-high-bg)' },
    medium: { color: 'var(--priority-medium)', bg: 'var(--priority-medium-bg)' },
    low: { color: 'var(--priority-low)', bg: 'var(--priority-low-bg)' },
  };
  return map[priority] || map.medium;
};

export const getInitials = (name = '') =>
  name.split(' ').map((n) => n[0]).join('').toUpperCase().slice(0, 2);

export const truncate = (str, n = 60) =>
  str && str.length > n ? str.slice(0, n) + '...' : str;
