import React, { createContext, useContext, useState, useCallback } from 'react';
import { taskService } from '../services/task.service';
import toast from 'react-hot-toast';

const TaskContext = createContext(null);

export const TaskProvider = ({ children }) => {
  const [tasks, setTasks] = useState([]);
  const [pagination, setPagination] = useState({ total: 0, page: 1, totalPages: 1 });
  const [stats, setStats] = useState({ all: 0, pending: 0, completed: 0 });
  const [loading, setLoading] = useState(false);
  const [filters, setFilters] = useState({ status: 'all', search: '', priority: '', page: 1, limit: 10 });

  const fetchTasks = useCallback(async (params = {}) => {
    setLoading(true);
    try {
      const merged = { ...filters, ...params };
      const res = await taskService.getTasks(merged);
      setTasks(res.tasks);
      setPagination(res.pagination);
      setStats(res.stats);
    } catch (err) {
      toast.error(err.message || 'Failed to load tasks');
    } finally {
      setLoading(false);
    }
  }, [filters]);

  const createTask = useCallback(async (data) => {
    const res = await taskService.createTask(data);
    toast.success('Task created!');
    await fetchTasks();
    return res;
  }, [fetchTasks]);

  const updateTask = useCallback(async (id, data) => {
    const res = await taskService.updateTask(id, data);
    setTasks((prev) => prev.map((t) => (t._id === id ? res.task : t)));
    toast.success('Task updated!');
    return res;
  }, []);

  const deleteTask = useCallback(async (id) => {
    await taskService.deleteTask(id);
    setTasks((prev) => prev.filter((t) => t._id !== id));
    toast.success('Task deleted');
    await fetchTasks();
  }, [fetchTasks]);

  const toggleTask = useCallback(async (id) => {
    const res = await taskService.toggleTask(id);
    setTasks((prev) => prev.map((t) => (t._id === id ? res.task : t)));
    await fetchTasks();
    return res;
  }, [fetchTasks]);

  const updateFilters = useCallback((newFilters) => {
    setFilters((prev) => ({ ...prev, ...newFilters, page: 1 }));
  }, []);

  return (
    <TaskContext.Provider value={{
      tasks, pagination, stats, loading, filters,
      fetchTasks, createTask, updateTask, deleteTask, toggleTask, updateFilters,
    }}>
      {children}
    </TaskContext.Provider>
  );
};

export const useTasks = () => {
  const ctx = useContext(TaskContext);
  if (!ctx) throw new Error('useTasks must be used within TaskProvider');
  return ctx;
};
