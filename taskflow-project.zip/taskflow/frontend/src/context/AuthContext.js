import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { authService } from '../services/auth.service';

const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(() => {
    try {
      const stored = localStorage.getItem('taskflow_user');
      return stored ? JSON.parse(stored) : null;
    } catch { return null; }
  });
  const [loading, setLoading] = useState(true);

  const saveUser = useCallback((userData, token) => {
    setUser(userData);
    localStorage.setItem('taskflow_user', JSON.stringify(userData));
    if (token) localStorage.setItem('taskflow_token', token);
  }, []);

  const logout = useCallback(() => {
    setUser(null);
    localStorage.removeItem('taskflow_token');
    localStorage.removeItem('taskflow_user');
  }, []);

  const register = useCallback(async (data) => {
    const res = await authService.register(data);
    saveUser(res.user, res.token);
    return res;
  }, [saveUser]);

  const login = useCallback(async (data) => {
    const res = await authService.login(data);
    saveUser(res.user, res.token);
    return res;
  }, [saveUser]);

  const updateUser = useCallback(async (data) => {
    const res = await authService.updateProfile(data);
    saveUser(res.user);
    return res;
  }, [saveUser]);

  useEffect(() => {
    const verifyToken = async () => {
      const token = localStorage.getItem('taskflow_token');
      if (!token) { setLoading(false); return; }
      try {
        const res = await authService.getMe();
        setUser(res.user);
        localStorage.setItem('taskflow_user', JSON.stringify(res.user));
      } catch {
        logout();
      } finally {
        setLoading(false);
      }
    };
    verifyToken();
  }, [logout]);

  return (
    <AuthContext.Provider value={{ user, loading, register, login, logout, updateUser }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used within AuthProvider');
  return context;
};
