import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import Input from '../components/common/Input';
import Button from '../components/common/Button';
import { getInitials } from '../utils/helpers';
import { authService } from '../services/auth.service';
import toast from 'react-hot-toast';
import './ProfilePage.css';

const ProfilePage = () => {
  const { user, updateUser } = useAuth();
  const [profileData, setProfileData] = useState({ name: user?.name || '', avatar: user?.avatar || '' });
  const [pwData, setPwData] = useState({ currentPassword: '', newPassword: '', confirmNewPassword: '' });
  const [saving, setSaving] = useState(false);
  const [changingPw, setChangingPw] = useState(false);
  const [errors, setErrors] = useState({});

  const handleProfileSave = async (e) => {
    e.preventDefault();
    if (!profileData.name.trim()) { setErrors({ name: 'Name is required' }); return; }
    setSaving(true);
    try { await updateUser(profileData); toast.success('Profile updated!'); setErrors({}); }
    catch (err) { toast.error(err.message); }
    finally { setSaving(false); }
  };

  const handlePasswordChange = async (e) => {
    e.preventDefault();
    if (pwData.newPassword !== pwData.confirmNewPassword) {
      setErrors({ confirmNewPassword: 'Passwords do not match' }); return;
    }
    setChangingPw(true);
    try {
      await authService.changePassword({ currentPassword: pwData.currentPassword, newPassword: pwData.newPassword });
      toast.success('Password changed!');
      setPwData({ currentPassword: '', newPassword: '', confirmNewPassword: '' });
      setErrors({});
    } catch (err) { toast.error(err.message); }
    finally { setChangingPw(false); }
  };

  return (
    <div className="profile-page fade-in">
      <div className="profile-card">
        <div className="profile-card__avatar-section">
          <div className="profile-card__avatar">{getInitials(user?.name)}</div>
          <div>
            <h2>{user?.name}</h2>
            <p>{user?.email}</p>
            <span className="profile-card__role">{user?.role}</span>
          </div>
        </div>

        <form onSubmit={handleProfileSave} className="profile-card__form">
          <h3>Personal Information</h3>
          <Input label="Full Name" name="name" value={profileData.name}
            onChange={(e) => setProfileData((p) => ({ ...p, name: e.target.value }))}
            error={errors.name} required
          />
          <Input label="Email" name="email" value={user?.email} disabled hint="Email cannot be changed" />
          <div className="profile-card__actions">
            <Button type="submit" loading={saving}>Save Changes</Button>
          </div>
        </form>
      </div>

      <div className="profile-card">
        <form onSubmit={handlePasswordChange} className="profile-card__form">
          <h3>Change Password</h3>
          <Input label="Current Password" name="currentPassword" type="password"
            value={pwData.currentPassword}
            onChange={(e) => setPwData((p) => ({ ...p, currentPassword: e.target.value }))}
            required
          />
          <Input label="New Password" name="newPassword" type="password"
            value={pwData.newPassword}
            onChange={(e) => setPwData((p) => ({ ...p, newPassword: e.target.value }))}
            hint="At least 6 characters" required
          />
          <Input label="Confirm New Password" name="confirmNewPassword" type="password"
            value={pwData.confirmNewPassword}
            onChange={(e) => setPwData((p) => ({ ...p, confirmNewPassword: e.target.value }))}
            error={errors.confirmNewPassword} required
          />
          <div className="profile-card__actions">
            <Button type="submit" loading={changingPw} variant="secondary">Change Password</Button>
          </div>
        </form>
      </div>

      <div className="profile-card profile-card--info">
        <h3>Account Details</h3>
        <div className="profile-card__detail-list">
          <div className="profile-card__detail">
            <span>Member since</span>
            <span>{user?.createdAt ? new Date(user.createdAt).toLocaleDateString('en-US', { month: 'long', year: 'numeric' }) : 'N/A'}</span>
          </div>
          <div className="profile-card__detail">
            <span>Account role</span>
            <span style={{ textTransform: 'capitalize' }}>{user?.role}</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProfilePage;
