import React from 'react';
import RegisterForm from '../components/auth/RegisterForm';
import './AuthPage.css';

const RegisterPage = () => (
  <div className="auth-page">
    <div className="auth-page__bg" />
    <RegisterForm />
  </div>
);

export default RegisterPage;
