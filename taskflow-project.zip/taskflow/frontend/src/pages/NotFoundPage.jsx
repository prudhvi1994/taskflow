import React from 'react';
import { Link } from 'react-router-dom';
import Button from '../components/common/Button';
import './NotFoundPage.css';

const NotFoundPage = () => (
  <div className="not-found">
    <h1>404</h1>
    <h2>Page not found</h2>
    <p>The page you are looking for does not exist.</p>
    <Link to="/dashboard"><Button>Go to Dashboard</Button></Link>
  </div>
);

export default NotFoundPage;
