import React from 'react';
import LoginForm from '../components/auth/LoginForm';
import './AuthPage.css';

const LoginPage = () => (
  <div className="auth-page">
    <div className="auth-page__bg" />
    <LoginForm />
  </div>
);

export default LoginPage;
