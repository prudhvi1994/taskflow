import React, { useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useTasks } from '../context/TaskContext';
import StatsCard from '../components/dashboard/StatsCard';
import RecentTasks from '../components/dashboard/RecentTasks';
import Button from '../components/common/Button';
import Spinner from '../components/common/Spinner';
import './DashboardPage.css';

const DashboardPage = () => {
  const { user } = useAuth();
  const { tasks, stats, loading, fetchTasks } = useTasks();

  useEffect(() => { fetchTasks({ limit: 10 }); }, [fetchTasks]);

  if (loading) return <Spinner centered />;

  const completionRate = stats.all > 0 ? Math.round((stats.completed / stats.all) * 100) : 0;

  return (
    <div className="dashboard fade-in">
      <div className="dashboard__welcome">
        <div>
          <h2>Good {getTimeOfDay()}, {user?.name?.split(' ')[0]}!</h2>
          <p>Here is your task overview for today.</p>
        </div>
        <Link to="/tasks">
          <Button size="md">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
              <line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/>
            </svg>
            New Task
          </Button>
        </Link>
      </div>

      <div className="dashboard__stats">
        <StatsCard label="Total Tasks" value={stats.all} color="var(--accent-primary)"
          description="All your tasks"
          icon={<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="3" y="3" width="18" height="18" rx="2"/><path d="M9 9h6M9 13h4"/></svg>}
        />
        <StatsCard label="Pending" value={stats.pending} color="var(--accent-warning)"
          description="Tasks in progress"
          icon={<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>}
        />
        <StatsCard label="Completed" value={stats.completed} color="var(--accent-success)"
          description="Tasks finished"
          icon={<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M9 11l3 3L22 4"/><path d="M21 12v7a2 2 0 01-2 2H5a2 2 0 01-2-2V5a2 2 0 012-2h11"/></svg>}
        />
        <StatsCard label="Completion" value={`${completionRate}%`} color="var(--accent-secondary)"
          description="Your productivity"
          icon={<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/></svg>}
        />
      </div>

      {stats.all > 0 && (
        <div className="dashboard__progress-card">
          <div className="dashboard__progress-header">
            <span>Overall Progress</span>
            <span className="dashboard__progress-pct">{completionRate}%</span>
          </div>
          <div className="dashboard__progress-bar">
            <div className="dashboard__progress-fill" style={{ width: `${completionRate}%` }} />
          </div>
          <p className="dashboard__progress-sub">{stats.completed} of {stats.all} tasks completed</p>
        </div>
      )}

      <RecentTasks tasks={tasks} />
    </div>
  );
};

const getTimeOfDay = () => {
  const h = new Date().getHours();
  if (h < 12) return 'morning';
  if (h < 17) return 'afternoon';
  return 'evening';
};

export default DashboardPage;
