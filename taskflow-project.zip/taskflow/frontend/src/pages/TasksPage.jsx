import React, { useEffect, useState } from 'react';
import { useTasks } from '../context/TaskContext';
import TaskCard from '../components/tasks/TaskCard';
import TaskForm from '../components/tasks/TaskForm';
import TaskFilters from '../components/tasks/TaskFilters';
import SearchBar from '../components/tasks/SearchBar';
import Modal from '../components/common/Modal';
import Button from '../components/common/Button';
import Spinner from '../components/common/Spinner';
import EmptyState from '../components/common/EmptyState';
import useDebounce from '../hooks/useDebounce';
import toast from 'react-hot-toast';
import './TasksPage.css';

const TasksPage = () => {
  const { tasks, stats, loading, filters, fetchTasks, createTask, updateTask, updateFilters } = useTasks();
  const [modalOpen, setModalOpen] = useState(false);
  const [editTask, setEditTask] = useState(null);
  const [formLoading, setFormLoading] = useState(false);
  const [searchInput, setSearchInput] = useState('');
  const debouncedSearch = useDebounce(searchInput, 400);

  useEffect(() => { fetchTasks(filters); }, [filters, fetchTasks]);
  useEffect(() => { updateFilters({ search: debouncedSearch }); }, [debouncedSearch, updateFilters]);

  const handleCreate = async (data) => {
    setFormLoading(true);
    try { await createTask(data); setModalOpen(false); }
    catch (err) { toast.error(err.message); }
    finally { setFormLoading(false); }
  };

  const handleUpdate = async (data) => {
    setFormLoading(true);
    try { await updateTask(editTask._id, data); setEditTask(null); }
    catch (err) { toast.error(err.message); }
    finally { setFormLoading(false); }
  };

  const openEdit = (task) => {
    setEditTask({ ...task, dueDate: task.dueDate ? task.dueDate.split('T')[0] : '', tags: (task.tags || []).join(', ') });
  };

  return (
    <div className="tasks-page fade-in">
      <div className="tasks-page__toolbar">
        <SearchBar value={searchInput} onChange={(e) => setSearchInput(e.target.value)} />
        <Button onClick={() => setModalOpen(true)}>
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
            <line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/>
          </svg>
          New Task
        </Button>
      </div>

      <TaskFilters filters={filters} onFilterChange={updateFilters} stats={stats} />

      {loading ? (
        <Spinner centered />
      ) : tasks.length === 0 ? (
        <EmptyState
          title={filters.search ? 'No tasks found' : 'No tasks yet'}
          description={filters.search ? `No tasks match "${filters.search}". Try a different search.` : 'Create your first task to get started!'}
          action={!filters.search && <Button onClick={() => setModalOpen(true)}>Create Task</Button>}
        />
      ) : (
        <div className="tasks-page__grid">
          {tasks.map((task) => (
            <TaskCard key={task._id} task={task} onEdit={openEdit} />
          ))}
        </div>
      )}

      <Modal isOpen={modalOpen} onClose={() => setModalOpen(false)} title="Create New Task">
        <TaskForm onSubmit={handleCreate} loading={formLoading} onCancel={() => setModalOpen(false)} />
      </Modal>

      <Modal isOpen={!!editTask} onClose={() => setEditTask(null)} title="Edit Task">
        {editTask && (
          <TaskForm
            initialValues={editTask}
            onSubmit={handleUpdate}
            loading={formLoading}
            onCancel={() => setEditTask(null)}
          />
        )}
      </Modal>
    </div>
  );
};

export default TasksPage;
