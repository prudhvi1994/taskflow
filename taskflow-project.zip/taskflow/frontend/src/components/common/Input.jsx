import React from 'react';
import './Input.css';

const Input = ({
  label, name, type = 'text', value, onChange, onBlur,
  error, placeholder, required, disabled, hint, ...props
}) => {
  return (
    <div className={`input-group ${error ? 'input-group--error' : ''}`}>
      {label && (
        <label className="input-label" htmlFor={name}>
          {label} {required && <span className="input-required">*</span>}
        </label>
      )}
      <input
        id={name}
        name={name}
        type={type}
        value={value}
        onChange={onChange}
        onBlur={onBlur}
        placeholder={placeholder}
        disabled={disabled}
        className="input-field"
        autoComplete="off"
        {...props}
      />
      {error && <p className="input-error">{error}</p>}
      {hint && !error && <p className="input-hint">{hint}</p>}
    </div>
  );
};

export default Input;
