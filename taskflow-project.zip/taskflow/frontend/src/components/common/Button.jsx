import React from 'react';
import './Button.css';

const Button = ({
  children, variant = 'primary', size = 'md', loading = false,
  disabled = false, fullWidth = false, onClick, type = 'button', className = '', ...props
}) => {
  return (
    <button
      type={type}
      onClick={onClick}
      disabled={disabled || loading}
      className={`btn btn--${variant} btn--${size} ${fullWidth ? 'btn--full' : ''} ${className}`}
      {...props}
    >
      {loading && <span className="btn__spinner" />}
      {children}
    </button>
  );
};

export default Button;
