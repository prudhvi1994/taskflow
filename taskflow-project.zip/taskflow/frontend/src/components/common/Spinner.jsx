import React from 'react';
import './Spinner.css';

const Spinner = ({ size = 'md', centered = false }) => (
  <div className={centered ? 'spinner-centered' : ''}>
    <div className={`spinner spinner--${size}`} />
  </div>
);

export default Spinner;
