import React from 'react';
import { Link } from 'react-router-dom';
import Badge from '../common/Badge';
import { formatDate, isOverdue } from '../../utils/helpers';
import './RecentTasks.css';

const RecentTasks = ({ tasks = [] }) => (
  <div className="recent-tasks">
    <div className="recent-tasks__header">
      <h2>Recent Tasks</h2>
      <Link to="/tasks" className="recent-tasks__view-all">View all →</Link>
    </div>
    {tasks.length === 0 ? (
      <p className="recent-tasks__empty">No tasks yet. Create your first task!</p>
    ) : (
      <ul className="recent-tasks__list">
        {tasks.slice(0, 5).map((task) => (
          <li key={task._id} className={`recent-task-item ${task.status === 'completed' ? 'recent-task-item--done' : ''}`}>
            <div className="recent-task-item__dot" style={{
              background: task.status === 'completed' ? 'var(--accent-success)' : 'var(--accent-primary)',
            }} />
            <div className="recent-task-item__content">
              <span className="recent-task-item__title">{task.title}</span>
              <span className="recent-task-item__date" style={{ color: isOverdue(task.dueDate, task.status) ? 'var(--accent-danger)' : undefined }}>
                {formatDate(task.dueDate)}
              </span>
            </div>
            <div className="recent-task-item__badges">
              <Badge variant={task.status === 'completed' ? 'success' : 'pending'}>{task.status}</Badge>
              <Badge variant={task.priority}>{task.priority}</Badge>
            </div>
          </li>
        ))}
      </ul>
    )}
  </div>
);

export default RecentTasks;
