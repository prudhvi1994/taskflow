import React from 'react';
import './StatsCard.css';

const StatsCard = ({ label, value, icon, color, description }) => (
  <div className="stats-card fade-in" style={{ '--card-color': color }}>
    <div className="stats-card__content">
      <p className="stats-card__label">{label}</p>
      <p className="stats-card__value">{value}</p>
      {description && <p className="stats-card__desc">{description}</p>}
    </div>
    <div className="stats-card__icon">{icon}</div>
  </div>
);

export default StatsCard;
