import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import useForm from '../../hooks/useForm';
import { validateLogin } from '../../utils/validators';
import Input from '../common/Input';
import Button from '../common/Button';
import toast from 'react-hot-toast';
import './AuthForm.css';

const LoginForm = () => {
  const { login } = useAuth();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);

  const { values, errors, touched, handleChange, handleBlur, handleSubmit } = useForm(
    { email: '', password: '' },
    validateLogin
  );

  const onSubmit = handleSubmit(async (vals) => {
    setLoading(true);
    try {
      await login(vals);
      toast.success('Welcome back!');
      navigate('/dashboard');
    } catch (err) {
      toast.error(err.message || 'Login failed');
    } finally {
      setLoading(false);
    }
  });

  return (
    <div className="auth-form">
      <div className="auth-form__header">
        <div className="auth-form__logo">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
            <path d="M9 11l3 3L22 4"/><path d="M21 12v7a2 2 0 01-2 2H5a2 2 0 01-2-2V5a2 2 0 012-2h11"/>
          </svg>
        </div>
        <h1>Welcome back</h1>
        <p>Sign in to manage your tasks</p>
      </div>

      <form onSubmit={onSubmit} className="auth-form__body" noValidate>
        <Input
          label="Email" name="email" type="email"
          value={values.email} onChange={handleChange} onBlur={handleBlur}
          error={touched.email && errors.email}
          placeholder="you@example.com" required
        />
        <Input
          label="Password" name="password" type="password"
          value={values.password} onChange={handleChange} onBlur={handleBlur}
          error={touched.password && errors.password}
          placeholder="Your password" required
        />
        <Button type="submit" fullWidth loading={loading} size="lg">Sign In</Button>
      </form>

      <p className="auth-form__footer">
        Don't have an account? <Link to="/register">Create one</Link>
      </p>
    </div>
  );
};

export default LoginForm;
