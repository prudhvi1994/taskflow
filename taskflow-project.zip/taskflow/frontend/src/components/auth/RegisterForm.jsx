import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import useForm from '../../hooks/useForm';
import { validateRegister } from '../../utils/validators';
import Input from '../common/Input';
import Button from '../common/Button';
import toast from 'react-hot-toast';
import './AuthForm.css';

const RegisterForm = () => {
  const { register } = useAuth();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);

  const { values, errors, touched, handleChange, handleBlur, handleSubmit } = useForm(
    { name: '', email: '', password: '', confirmPassword: '' },
    validateRegister
  );

  const onSubmit = handleSubmit(async (vals) => {
    setLoading(true);
    try {
      await register(vals);
      toast.success('Account created! Welcome!');
      navigate('/dashboard');
    } catch (err) {
      toast.error(err.message || 'Registration failed');
    } finally {
      setLoading(false);
    }
  });

  return (
    <div className="auth-form">
      <div className="auth-form__header">
        <div className="auth-form__logo">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
            <path d="M9 11l3 3L22 4"/><path d="M21 12v7a2 2 0 01-2 2H5a2 2 0 012-2h11"/>
          </svg>
        </div>
        <h1>Create account</h1>
        <p>Start managing your tasks today</p>
      </div>

      <form onSubmit={onSubmit} className="auth-form__body" noValidate>
        <Input
          label="Full Name" name="name" value={values.name}
          onChange={handleChange} onBlur={handleBlur}
          error={touched.name && errors.name}
          placeholder="John Doe" required
        />
        <Input
          label="Email" name="email" type="email" value={values.email}
          onChange={handleChange} onBlur={handleBlur}
          error={touched.email && errors.email}
          placeholder="you@example.com" required
        />
        <Input
          label="Password" name="password" type="password" value={values.password}
          onChange={handleChange} onBlur={handleBlur}
          error={touched.password && errors.password}
          placeholder="Min 6 characters" required
          hint="At least 6 characters"
        />
        <Input
          label="Confirm Password" name="confirmPassword" type="password" value={values.confirmPassword}
          onChange={handleChange} onBlur={handleBlur}
          error={touched.confirmPassword && errors.confirmPassword}
          placeholder="Repeat your password" required
        />
        <Button type="submit" fullWidth loading={loading} size="lg">Create Account</Button>
      </form>

      <p className="auth-form__footer">
        Already have an account? <Link to="/login">Sign in</Link>
      </p>
    </div>
  );
};

export default RegisterForm;
