import React, { useState } from 'react';
import Badge from '../common/Badge';
import ConfirmDialog from '../common/ConfirmDialog';
import { formatDate, isOverdue } from '../../utils/helpers';
import { useTasks } from '../../context/TaskContext';
import toast from 'react-hot-toast';
import './TaskCard.css';

const TaskCard = ({ task, onEdit }) => {
  const { deleteTask, toggleTask } = useTasks();
  const [showConfirm, setShowConfirm] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [toggling, setToggling] = useState(false);

  const handleDelete = async () => {
    setDeleting(true);
    try { await deleteTask(task._id); }
    catch (err) { toast.error(err.message); }
    finally { setDeleting(false); setShowConfirm(false); }
  };

  const handleToggle = async () => {
    setToggling(true);
    try { await toggleTask(task._id); }
    catch (err) { toast.error(err.message); }
    finally { setToggling(false); }
  };

  const overdue = isOverdue(task.dueDate, task.status);

  return (
    <>
      <div className={`task-card fade-in ${task.status === 'completed' ? 'task-card--completed' : ''} ${overdue ? 'task-card--overdue' : ''}`}>
        <div className="task-card__top">
          <button
            className={`task-card__check ${task.status === 'completed' ? 'task-card__check--done' : ''} ${toggling ? 'task-card__check--spinning' : ''}`}
            onClick={handleToggle} disabled={toggling}
            aria-label="Toggle completion"
          >
            {task.status === 'completed' && (
              <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3">
                <polyline points="20 6 9 17 4 12"/>
              </svg>
            )}
          </button>
          <div className="task-card__badges">
            <Badge variant={task.priority}>{task.priority}</Badge>
            {overdue && <Badge variant="danger">Overdue</Badge>}
          </div>
          <div className="task-card__actions">
            <button className="task-card__action-btn" onClick={() => onEdit(task)} title="Edit">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7"/>
                <path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z"/>
              </svg>
            </button>
            <button className="task-card__action-btn task-card__action-btn--delete" onClick={() => setShowConfirm(true)} title="Delete">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 01-2 2H8a2 2 0 01-2-2L5 6"/>
                <path d="M10 11v6M14 11v6M9 6V4a1 1 0 011-1h4a1 1 0 011 1v2"/>
              </svg>
            </button>
          </div>
        </div>

        <div className="task-card__body">
          <h3 className="task-card__title">{task.title}</h3>
          {task.description && <p className="task-card__desc">{task.description}</p>}
        </div>

        <div className="task-card__footer">
          {task.dueDate && (
            <span className="task-card__date" style={{ color: overdue ? 'var(--accent-danger)' : undefined }}>
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/>
                <line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/>
              </svg>
              {formatDate(task.dueDate)}
            </span>
          )}
          {task.tags?.length > 0 && (
            <div className="task-card__tags">
              {task.tags.slice(0, 2).map((tag) => (
                <span key={tag} className="task-card__tag">#{tag}</span>
              ))}
              {task.tags.length > 2 && <span className="task-card__tag">+{task.tags.length - 2}</span>}
            </div>
          )}
        </div>
      </div>

      <ConfirmDialog
        isOpen={showConfirm} onClose={() => setShowConfirm(false)}
        onConfirm={handleDelete} loading={deleting}
        title="Delete Task"
        message={`Are you sure you want to delete "${task.title}"? This cannot be undone.`}
      />
    </>
  );
};

export default TaskCard;
