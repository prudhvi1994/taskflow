import React from 'react';
import './TaskFilters.css';

const STATUSES = [
  { value: 'all', label: 'All' },
  { value: 'pending', label: 'Pending' },
  { value: 'completed', label: 'Completed' },
];

const PRIORITIES = [
  { value: '', label: 'Any Priority' },
  { value: 'high', label: 'High' },
  { value: 'medium', label: 'Medium' },
  { value: 'low', label: 'Low' },
];

const TaskFilters = ({ filters, onFilterChange, stats }) => {
  return (
    <div className="task-filters">
      <div className="task-filters__status">
        {STATUSES.map(({ value, label }) => (
          <button
            key={value}
            className={`task-filters__tab ${filters.status === value ? 'task-filters__tab--active' : ''}`}
            onClick={() => onFilterChange({ status: value })}
          >
            {label}
            <span className="task-filters__count">{stats[value] || 0}</span>
          </button>
        ))}
      </div>

      <select
        className="task-filters__select"
        value={filters.priority || ''}
        onChange={(e) => onFilterChange({ priority: e.target.value })}
      >
        {PRIORITIES.map(({ value, label }) => (
          <option key={value} value={value}>{label}</option>
        ))}
      </select>
    </div>
  );
};

export default TaskFilters;
