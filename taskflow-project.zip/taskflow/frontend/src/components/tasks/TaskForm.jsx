import React from 'react';
import useForm from '../../hooks/useForm';
import { validateTask } from '../../utils/validators';
import Input from '../common/Input';
import Button from '../common/Button';
import './TaskForm.css';

const PRIORITIES = ['low', 'medium', 'high'];

const TaskForm = ({ initialValues, onSubmit, loading, onCancel }) => {
  const defaults = { title: '', description: '', priority: 'medium', dueDate: '', tags: '', ...initialValues };
  const { values, errors, touched, handleChange, handleBlur, handleSubmit, setValue } = useForm(defaults, validateTask);

  const submit = handleSubmit(async (vals) => {
    const data = {
      ...vals,
      tags: vals.tags ? vals.tags.split(',').map((t) => t.trim()).filter(Boolean) : [],
    };
    await onSubmit(data);
  });

  return (
    <form onSubmit={submit} className="task-form" noValidate>
      <Input
        label="Task Title" name="title" value={values.title}
        onChange={handleChange} onBlur={handleBlur}
        error={touched.title && errors.title}
        placeholder="What needs to be done?" required
      />

      <div className="task-form__group">
        <label className="task-form__label">Description</label>
        <textarea
          name="description" value={values.description}
          onChange={handleChange} onBlur={handleBlur}
          placeholder="Add details (optional)"
          className={`task-form__textarea ${touched.description && errors.description ? 'task-form__textarea--error' : ''}`}
          rows={3}
        />
        {touched.description && errors.description && (
          <p className="task-form__error">{errors.description}</p>
        )}
      </div>

      <div className="task-form__row">
        <div className="task-form__group">
          <label className="task-form__label">Priority</label>
          <div className="task-form__priority">
            {PRIORITIES.map((p) => (
              <button key={p} type="button"
                className={`task-form__priority-btn task-form__priority-btn--${p} ${values.priority === p ? 'active' : ''}`}
                onClick={() => setValue('priority', p)}
              >
                {p}
              </button>
            ))}
          </div>
        </div>

        <Input
          label="Due Date" name="dueDate" type="date"
          value={values.dueDate ? values.dueDate.split('T')[0] : ''}
          onChange={handleChange} onBlur={handleBlur}
        />
      </div>

      <Input
        label="Tags" name="tags"
        value={typeof values.tags === 'string' ? values.tags : (values.tags || []).join(', ')}
        onChange={handleChange}
        placeholder="work, personal, urgent (comma separated)"
        hint="Separate tags with commas"
      />

      <div className="task-form__actions">
        {onCancel && <Button variant="secondary" onClick={onCancel} type="button">Cancel</Button>}
        <Button type="submit" loading={loading}>
          {initialValues ? 'Update Task' : 'Create Task'}
        </Button>
      </div>
    </form>
  );
};

export default TaskForm;
